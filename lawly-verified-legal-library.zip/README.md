# Lawly Verified Legal Library

This pack gives Lawly a safer anti-hallucination architecture.

## Files

Paste into your Next.js project:

```txt
/lib/legal-content.ts
/lib/scenario-classifier.ts
/lib/fallback-guidance.ts
/lib/prompts.ts
```

## What this does

Lawly should work like this:

```txt
User says anything
→ deterministic classifier picks a scenario
→ if supported: load verified content from legal-content.ts
→ Gemini receives only that content
→ Gemini explains/formats it
→ if unsupported: show safe orientation only
```

## Supported detailed scenarios

- housing_deposit
- housing_repairs
- housing_rent_increase
- housing_eviction_notice

## Unsupported categories handled safely

- work
- consumer
- government
- family
- immigration
- criminal
- debt
- school
- unknown

## Claude Code integration prompt

Paste this into Claude Code after adding the files:

```txt
I added these files:
- /lib/legal-content.ts
- /lib/scenario-classifier.ts
- /lib/fallback-guidance.ts
- /lib/prompts.ts

Update /app/api/analyze/route.ts so it:
1. receives user input
2. calls classifyScenario(userInput)
3. if supported, loads housingScenarios[scenarioId]
4. sends only that scenario JSON to Gemini using buildSupportedScenarioPrompt
5. if unsupported, loads getFallbackGuidance(category)
6. sends only the fallback JSON to Gemini using buildUnsupportedScenarioPrompt
7. returns JSON to the frontend

Do not let Gemini answer from memory.
Do not add RAG, database, OpenJustice, embeddings, or scraping.
Keep Vertex AI setup unchanged.
Keep app lightweight.

Update /app/api/letter/route.ts so it only generates documents for supported scenarios using buildDocumentPrompt and the verified scenario JSON.

If scenario is unsupported, return a general_case_summary only.
```

## Source note

Official LegisQuébec pages were used for the key legal article excerpts:
- Article 1904 C.C.Q.
- Article 1854 C.C.Q.
- Article 1910 C.C.Q.
- Article 1942 C.C.Q.
- Article 1945 C.C.Q.
- Article 1957 C.C.Q.
- Article 1960 C.C.Q.
